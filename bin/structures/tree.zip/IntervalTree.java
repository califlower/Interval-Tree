package structures;

import java.util.*;

/**
 * Encapsulates an interval tree.
 * 
 * @author runb-cs112
 */
public class IntervalTree {
	
	/**
	 * The root of the interval tree
	 */
	IntervalTreeNode root;
	
	/**
	 * Constructs entire interval tree from set of input intervals. Constructing the tree
	 * means building the interval tree structure and mapping the intervals to the nodes.
	 * 
	 * @param intervals Array list of intervals for which the tree is constructed
	 */
	public IntervalTree(ArrayList<Interval> intervals) {
		
		// make a copy of intervals to use for right sorting
		ArrayList<Interval> intervalsRight = new ArrayList<Interval>(intervals.size());
		for (Interval iv : intervals) {
			intervalsRight.add(iv);
		}
		
		// rename input intervals for left sorting
		ArrayList<Interval> intervalsLeft = intervals;
		
		// sort intervals on left and right end points
		Sorter.sortIntervals(intervalsLeft, 'l');
		Sorter.sortIntervals(intervalsRight,'r');
		
		// get sorted list of end points without duplicates
		ArrayList<Integer> sortedEndPoints = Sorter.getSortedEndPoints(intervalsLeft, intervalsRight);
		System.out.println(sortedEndPoints.toString());
		// build the tree nodes
		root = buildTreeNodes(sortedEndPoints);
		
		// map intervals to the tree nodes
		mapIntervalsToTree(intervalsLeft, intervalsRight);
	}
	
	/**
	 * Builds the interval tree structure given a sorted array list of end points.
	 * 
	 * @param endPoints Sorted array list of end points
	 * @return Root of the tree structure
	 */
	public static IntervalTreeNode buildTreeNodes(ArrayList<Integer> endPoints) 
	{
		
		/*Queue<IntervalTreeNode> queue =new Queue <IntervalTreeNode>();
		
		
		
		for (int i=0;i<endPoints.size()i++)
		{
			//IntervalTreeNode T.;
		}
		
		for (int i=0; i<endPoints.size(); i++)
		{
			//T=queue.dequeue();
			//queue.enqueue(T);
		}
		
		
		//Step 6
		
		int s=queue.size();
		IntervalTreeNode finalVal=null;
		
		while (s>0)
		{
			
			if (s==1)
			{
				finalVal=queue.dequeue();
				return finalVal;
			}
			
			else
			{
				
			
				int temp=s;
			
				while (temp>1)
				{
					
					IntervalTreeNode T1=queue.dequeue();
					IntervalTreeNode T2=queue.dequeue();
					
					float v1=T1.maxSplitValue;
					float v2=T2.minSplitValue;
					
					float split=(v1+v2)/2;
					
					IntervalTreeNode N= new IntervalTreeNode(split,v1,v2);
					
					N.leftChild=T1;
					N.rightChild=T2;
					queue.enqueue(N);
					
					temp=temp-2;
				}
				if (temp==1)
				{
					IntervalTreeNode tempNode=queue.dequeue();
					queue.enqueue(tempNode);
				}
			}
			//s=queue.size;
		
		}*/	
		//finalVal=queue.dequeue();
		return null;
	}
	
	/**
	 * Maps a set of intervals to the nodes of this interval tree. 
	 * 
	 * @param leftSortedIntervals Array list of intervals sorted according to left endpoints
	 * @param rightSortedIntervals Array list of intervals sorted according to right endpoints
	 */
	public void mapIntervalsToTree(ArrayList<Interval> leftSortedIntervals, ArrayList<Interval> rightSortedIntervals) {
		for (int i=0; i<leftSortedIntervals.size();i++)
		{
			treeSearch(root, leftSortedIntervals.get(i), "L");
		}
		
		for (int i=0; i<rightSortedIntervals.size();i++)
		{
			treeSearch(root, leftSortedIntervals.get(i), "R"); 	
		}
		return;
	}
	private void treeSearch(IntervalTreeNode root, Interval iteratedInterval, String side)
	{
		if (iteratedInterval.contains(root.splitValue))
		{
			if (side.compareTo("L")==0)
			{
				root.leftIntervals.add(iteratedInterval);
			}
			if (side.compareTo("R")==0)
			{
				root.rightIntervals.add(iteratedInterval);
			}
			return;
			
		}
		
		if (root.splitValue<iteratedInterval.leftEndPoint)
		{
			treeSearch(root.rightChild, iteratedInterval, "L");
			
		}
		else
		{
			treeSearch(root.leftChild, iteratedInterval, "L");
		}
	}
	
	/**
	 * Gets all intervals in this interval tree that intersect with a given interval.
	 * 
	 * @param q The query interval for which intersections are to be found
	 * @return Array list of all intersecting intervals; size is 0 if there are no intersections
	 */
	public ArrayList<Interval> findIntersectingIntervals(Interval q) 
	{
		// COMPLETE THIS METHOD
		// THE FOLLOWING LINE HAS BEEN ADDED TO MAKE THE PROGRAM COMPILE
		return null;
	}
	
	/**
	 * Returns the root of this interval tree.
	 * 
	 * @return Root of interval tree.
	 */
	public IntervalTreeNode getRoot() {
		return root;
	}
}

